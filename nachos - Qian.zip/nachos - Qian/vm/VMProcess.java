package nachos.vm;

import nachos.machine.*;
import nachos.threads.*;
import nachos.userprog.*;
import nachos.vm.*;
import java.util.*;

/**
 * A <tt>UserProcess</tt> that supports demand-paging.
 */
public class VMProcess extends UserProcess {
	/**
	 * Allocate a new process.
	 */
	public VMProcess() {
		super();
		for (int i = 0; i < numPhysPages; i++)
			VMKernel.clockFramesProcesses[i] = null; 
	}

	/**
	 * Save the state of this process in preparation for a context switch.
	 * Called by <tt>UThread.saveState()</tt>.
	 */
	public void saveState() {
		super.saveState();
		System.out.println("context switch");
		for (int i = 0; i < Machine.processor().getTLBSize(); i++) {
            TranslationEntry entry = Machine.processor().readTLBEntry(i);
            if (entry.valid == true)
                syncPageTablewithTLB(entry);
			entry.valid = false;
			Machine.processor().writeTLBEntry(i, entry);
		}
	}
    
	/**
	 * Restore the state of this process after a context switch. Called by
	 * <tt>UThread.restoreState()</tt>.
	 */
	public void restoreState() {
		//super.restoreState();
	}

	/**
	 * Initializes page tables for this process so that the executable can be
	 * demand-paged.
	 * 
	 * @return <tt>true</tt> if successful.
	 */
	protected boolean loadSections() {
		// allocate memory
		VMKernel.memoryLock.acquire();

		System.out.println("\tnum pages: " + numPages);

		pageTable = new TranslationEntry[numPages];

		for (int vpn=0; vpn<numPages; vpn++) {
	    	pageTable[vpn] = new TranslationEntry(-1, -1,
						  	false, false, false, false);
		}
	
		VMKernel.memoryLock.release();

		return true;
	}

	/**
	 * Load a coff section when needed.
	 */
	protected int isCoffSection(int loadVPN) {
		for (int s=0; s<coff.getNumSections(); s++) {
	    	CoffSection section = coff.getSection(s);
	    
	    	System.out.println("\tinitializing " + section.getName()
		    		  + " section (" + section.getLength() + " pages)");

	    	for (int i=0; i<section.getLength(); i++) {
				int vpn = section.getFirstVPN()+i;
				if (loadVPN == vpn) {
					System.out.println("# of section: " + s);
					return s;	
				}
   			}
		}

		return -1;
	}

	/**
	 * Release any resources allocated by <tt>loadSections()</tt>.
	 */
	protected void unloadSections() {
		super.unloadSections();
	}    
    
	/**
	 * Handle a user exception. Called by <tt>UserKernel.exceptionHandler()</tt>
	 * . The <i>cause</i> argument identifies which exception occurred; see the
	 * <tt>Processor.exceptionZZZ</tt> constants.
	 * 
	 * @param cause the user exception that occurred.
	 */
	public void handleException(int cause) {
		Processor processor = Machine.processor();

		switch (cause) {
			case Processor.exceptionTLBMiss:
                System.out.println("handleException handleTLBMiss");
				handleTLBMiss(processor.readRegister(Processor.regBadVAddr));
				break;

            default:
                System.out.println("handleException (" + cause + ")");
                super.handleException(cause);
                break;
		}
	}

	/**
	 * Handle TLBMiss execption. Try to get a postion for the new requested 
	 * TLB location. Evict an entry when no empty space left.
	 * 
	 * @param vaddr the missed virtual address.
	 */
	private void handleTLBMiss(int vaddr) {
		int vpn = Machine.processor().pageFromAddress(vaddr); 
		System.out.println("handleTLBMiss vpn (" + vpn + ")");

		TranslationEntry pageTableEntry = pageTable[vpn];
		TranslationEntry entry = new TranslationEntry(vpn, pageTableEntry.ppn, 
			pageTableEntry.valid, pageTableEntry.readOnly, pageTableEntry.used, pageTableEntry.dirty);

		System.out.println("is PTE valid? (" + pageTableEntry.valid + "," + pageTableEntry.vpn + ")");
		
		int pos = getTLBPosition();
		if (pos == -1) {
			System.out.println("TLB is full");
			int evictPos = Lib.random(Machine.processor().getTLBSize());
			System.out.println("TLB evict postion: " + evictPos);
			TranslationEntry tlbEntry = Machine.processor().readTLBEntry(evictPos);
			syncPageTablewithTLB(tlbEntry);			 	
		}

		if (!pageTable[vpn].valid)
			handlePageFault(vpn);

		syncTLBwithPageTable(pos, vpn);
	}

	/**
	 * If the PTE is unmapped or swapped out or evited and in coff,
	 * retrieve or allocate a new physical page. 
	 */
	private void retrievePage(int vpn, int ppn) {
		System.out.println("retrieve vpn: " + vpn);
		if (pageTable[vpn].vpn == -1) {
			int sectionNumber = isCoffSection(vpn);
			if (sectionNumber >= 0) {
				CoffSection section = coff.getSection(sectionNumber);
				pageTable[vpn].readOnly = section.isReadOnly();
				System.out.println("sectionNumber: " + sectionNumber + "section length: " + section.getLength());
				section.loadPage(vpn-section.getFirstVPN(), ppn);
			}
          	else {
          		Arrays.fill(Machine.processor().getMemory(), 
          			ppn*pageSize, (ppn+1)*pageSize, (byte)0);
          	}			
		}
		else {
			//When spn != -1 && valid = false, this page must have been swapped out.
            //System.out.println("vpn = " + vpn + " spn = " + pageTableEntry.vpn + " has been swapped out");
			VMKernel.swapIn(pageTable[vpn].vpn, ppn);
            //System.out.println("swapped In, spn = " + pageTableEntry.vpn + " ppn = " + pageTableEntry.ppn);
                
			//Update page table and TLB.
           	pageTable[vpn].vpn = -1;
		} 	
	}

	/**
	 * Get an empty TLB position.
	 *
	 * @return pos -1 means no empty sapce left.
	 */
	private int getTLBPosition() {
		int TLBSzie = Machine.processor().getTLBSize();
		for (int i = 0; i < TLBSzie; i++) {
			TranslationEntry entry = Machine.processor().readTLBEntry(i);
			if (entry.valid == false) 
				return i;
		}

		return -1;
	}

	/**
	 * Sync the page table entry with TLB entry.
	 *
	 * @param the index of TLB we want to sync to page table.
	 */
	private void syncPageTablewithTLB(TranslationEntry entry) {
		int vpn = entry.vpn;
		pageTable[vpn].ppn = entry.ppn;
		pageTable[vpn].valid = entry.valid;
		pageTable[vpn].readOnly = entry.readOnly;
		pageTable[vpn].used = entry.used;
		pageTable[vpn].dirty = entry.dirty;
	}

	/**
	 * Handle page fault(when the page table entry is marked as invalid).
	 * Get a physical frame when there're free frames left; or do page eviction.
	 * 
	 * @param vpn the index and vpn the invalid page table entry. 
	 */
	private void handlePageFault(int vpn) {
		System.out.println("handlePageFault");
		if (!VMKernel.isAnyFreePage()) {
			syncAllTLB();
			evictFramewithClock();
			syncAllPTE();
		}

		int ppn = VMKernel.getFreePage();
		VMKernel.clockFramesProcesses[ppn] = this;
		pageTable[vpn].ppn = ppn;
		pageTable[vpn].valid = true;

		retrievePage(vpn, ppn);
	}
    
	/**
	 * Sync the TLB entry with page table entry, except vpn.
	 *
	 * @param i the index of TLB we want to sync from page table.
     * @param vpn we want to always keep the true vpn inside TLB entry.
	 */
	private void syncTLBwithPageTable(int i, int vpn) {
		if (i < 0 || i > Machine.processor().getTLBSize())
			return;

		TranslationEntry entry = Machine.processor().readTLBEntry(i);
		entry.vpn = vpn;
		entry.ppn = pageTable[vpn].ppn;
		entry.valid = pageTable[vpn].valid;
		entry.readOnly = pageTable[vpn].readOnly;
		entry.used = pageTable[vpn].used;
		entry.dirty = pageTable[vpn].dirty;
		Machine.processor().writeTLBEntry(i, entry);
	}

	/** 
	 * Find if there's a TLB entry with the specified vpn.
	 *
	 * @param vpn the vpn of a page table entry
	 * @return i the index of TLB entry; 
	 * -1 means no such entry in TLB 
	 */
	private int getTLBIndexwithPageTableVPN(int vpn) {
		for (int i = 0; i < Machine.processor().getTLBSize(); i++) {
			 	TranslationEntry entry = Machine.processor().readTLBEntry(i);
			 	if (entry.vpn == vpn && entry.valid) 
			 		return i;
		}

		return -1;
	}

	/**
	 * Evict a frame based on the clock algorithm, and return the ppn of the 
	 * evicted frame.
	 * Clock algorithm: use a handler to go through the list of frames circularly,
	 * if the frame the handler currently points to is recently used, reset its bit;
	 * if the frame the handler currently points to is not recently used, evict this
	 * page and mark it as recently used.	
	 * Besides, if this page is pinned due to it's being read/written, it should also 
	 * be jumped over.
	 *
	 * @return ppn the ppn of the evicted frame.
	 */
	public void evictFramewithClock() {
		//Handle a corner case: if at the moment, all pages are pinned, the eviction must 
		//be deferred until one of the pages is unpinned.
		VMKernel.pinLock.acquire();
		while (pinCount == numPhysPages) 
			waitForUnpinned.sleep();
        
  //       boolean flag = true;
		// while (flag) {
		// 	if (VMKernel.clockFramesProcesses[clockHandler] == null) {
		// 		clockHandler = (clockHandler+1) % numPhysPages;
		// 		continue;
		// 	}
		// 	if (clockFramesPinned[clockHandler] == true) {	
		// 		VMKernel.clockFramesProcesses[clockHandler].pageTable[VMKernel.clockFramesProcesses[clockHandler].invertedPageTable[clockHandler]].used = false;
		// 		clockHandler = (clockHandler+1) % numPhysPages;
		// 		continue;
		// 	}
		// 	if (VMKernel.clockFramesProcesses[clockHandler].pageTable[VMKernel.clockFramesProcesses[clockHandler].invertedPageTable[clockHandler]].used == true) {
		// 		VMKernel.clockFramesProcesses[clockHandler].pageTable[VMKernel.clockFramesProcesses[clockHandler].invertedPageTable[clockHandler]].used = false;
		// 		clockHandler = (clockHandler+1) % numPhysPages;
		// 		continue;
		// 	}
		// 	else { 
		// 		flag = false;
		// 		break;
		// 	}
		// }
		
		while (checkUsedByppn(clockHandler) || clockFramesPinned[clockHandler]){
			// Lib.debug(dbgProcess, "current clockHandler for clock replacement is ppn: " + clockHandler);
			setUnusedByppn(clockHandler);	
			clockHandler = (clockHandler + 1) % (numPhysPages);
		}
		
		int toEvict = clockHandler;
		clockHandler = (clockHandler + 1) % (numPhysPages);


		if (isDirty(toEvict)){
			// execute swapping out
			Lib.debug(dbgProcess, "execute swapping out");
			int swapNumber = VMKernel.swapOut(toEvict);
			setspnByppn(toEvict, swapNumber); 
		}

		// invalidate PTE and TLB entry for the clockHandler page
		Lib.debug(dbgProcess, "invalidate PTE and TLB entry for the clockHandler page");
		for (int i = 0; i < Machine.processor().getTLBSize(); i ++){
			TranslationEntry tlbEntry = Machine.processor().readTLBEntry(i);
			if (tlbEntry.ppn == toEvict){
				tlbEntry.valid = false;
				Machine.processor().writeTLBEntry(i, tlbEntry);
				break;
			}
		}
		setInvalidByppn(toEvict);

		// release the page
		VMKernel.returnPage(toEvict);
		//VMKernel.clockLock.release();


		VMKernel.pinLock.release();

		// int toEvictPPN = clockHandler;

		// // if (VMKernel.clockFramesProcesses[clockHandler] != null &&
		// // 	VMKernel.clockFramesProcesses[clockHandler].pageTable[VMKernel.clockFramesProcesses[clockHandler].invertedPageTable[clockHandler]].dirty == true) {
		// // 	int spn = VMKernel.swapOut(toEvictPPN);
		// // 	VMKernel.clockFramesProcesses[clockHandler].pageTable[VMKernel.clockFramesProcesses[clockHandler].invertedPageTable[clockHandler]].vpn = spn;
		// // 	VMKernel.clockFramesProcesses[clockHandler].pageTable[VMKernel.clockFramesProcesses[clockHandler].invertedPageTable[clockHandler]].valid = false;
		// // }

		// int tlbVPN = invertedPageTable[toEvictPPN];
		// int TLBIndex = getTLBIndexwithPageTableVPN(tlbVPN);
		// TranslationEntry tlbEntry = Machine.processor().readTLBEntry(TLBIndex);
		// tlbEntry.valid = false;
		// Machine.processor().writeTLBEntry(TLBIndex, tlbEntry);

		// System.out.println("clock evict: " + toEvictPPN);

		// VMKernel.returnPage(toEvictPPN);
	}

	 /**
     * Transfer data from this process's virtual memory to the specified array.
     * This method handles address translation details. This method must
     * <i>not</i> destroy the current process if an error occurs, but instead
     * should return the number of bytes successfully copied (or zero if no
     * data could be copied).
     *
     * @param	vaddr	the first byte of virtual memory to read.
     * @param	data	the array where the data will be stored.
     * @param	offset	the first byte to write in the array.
     * @param	length	the number of bytes to transfer from virtual memory to
     *			the array.
     * @return	the number of bytes successfully transferred.
     */
    public int readVirtualMemory(int vaddr, byte[] data, int offset,
				 int length) {
    	Lib.assertTrue(offset >= 0 && length >= 0 && offset+length <= data.length);

		byte[] memory = Machine.processor().getMemory();
	
		int amount = 0;

		while (length > 0) {
	    	int vpn = Processor.pageFromAddress(vaddr);
	    	int off = Processor.offsetFromAddress(vaddr);

	    	if (!pageTable[vpn].valid) 
	    		handlePageFault(vpn);

	    	int transfer = Math.min(length, pageSize-off);

	    	int ppn = pinVirtualPage(vpn, false);
	    	if (ppn == -1)
				break;

	    	System.arraycopy(memory, ppn*pageSize + off, data, offset,
				     transfer);

	    	unpinVirtualPage(vpn);
	    
	    	vaddr += transfer;
	    	offset += transfer;
	    	amount += transfer;
	    	length -= transfer;	    
		}

		return amount;
    }

    /**
     * Transfer data from the specified array to this process's virtual memory.
     * This method handles address translation details. This method must
     * <i>not</i> destroy the current process if an error occurs, but instead
     * should return the number of bytes successfully copied (or zero if no
     * data could be copied).
     *
     * @param	vaddr	the first byte of virtual memory to write.
     * @param	data	the array containing the data to transfer.
     * @param	offset	the first byte to transfer from the array.
     * @param	length	the number of bytes to transfer from the array to
     *			virtual memory.
     * @return	the number of bytes successfully transferred.
     */
    public int writeVirtualMemory(int vaddr, byte[] data, int offset,
				  int length) {
    	Lib.assertTrue(offset >= 0 && length >= 0 && offset+length <= data.length);

		byte[] memory = Machine.processor().getMemory();
	
		int amount = 0;

		while (length > 0) {
	    	int vpn = Processor.pageFromAddress(vaddr);
	    	int off = Processor.offsetFromAddress(vaddr);

	    	if (!pageTable[vpn].valid) 
	    		handlePageFault(vpn);

	    	int transfer = Math.min(length, pageSize-off);

	    	int ppn = pinVirtualPage(vpn, true);
	    	if (ppn == -1)
				break;

	    	System.arraycopy(data, offset, memory, ppn*pageSize + off,
			    	 transfer);
	    
	    	unpinVirtualPage(vpn);
	    
	    	vaddr += transfer;
	    	offset += transfer;
	    	amount += transfer;
	    	length -= transfer;	    
		}

		return amount;
    }

	protected int pinVirtualPage(int vpn, boolean isUserWrite) {
		if (vpn < 0 || vpn >= pageTable.length)
	    	return -1;

		TranslationEntry entry = pageTable[vpn];
        
        VMKernel.pageTableLock.acquire();
		if (isUserWrite) {
	    	if (entry.readOnly)
				return -1;
	    	entry.dirty = true;
		}

		entry.used = true;
		VMKernel.pageTableLock.release();

		VMKernel.pinLock.acquire();
        //Update clockFramesProcess.
		clockFramesPinned[entry.ppn] = true;
        pinCount++;
        VMKernel.pinLock.release();

		return entry.ppn;
    }
    
    protected void unpinVirtualPage(int vpn) {
    	pinCount--;
    	clockFramesPinned[pageTable[vpn].ppn] = false;

    	VMKernel.pinLock.acquire();
        waitForUnpinned.wakeAll();
        VMKernel.pinLock.release();
    }

    /**
     * Sync all entries in TLB to PT.
     */
    private void syncAllPTE() {
    	for (int i = 0; i < Machine.processor().getTLBSize(); i++) {
    		TranslationEntry entry = Machine.processor().readTLBEntry(i);
    		if (entry.valid)
    			syncPageTablewithTLB(entry); 
    	}
    }

    /**
     * Sync all entries in PT to TLB.
     */
    private void syncAllTLB() {
    	for (int i = 0; i < Machine.processor().getTLBSize(); i++){ 
    		TranslationEntry tlbEntry = Machine.processor().readTLBEntry(i);
    		if (tlbEntry.valid) 
    			syncTLBwithPageTable(i, tlbEntry.vpn);
    	}
    }

	public static Boolean isDirty(int ppn){
		if (VMKernel.clockFramesProcesses[ppn] == null) return false;
		for (int i = 0; i < (VMKernel.clockFramesProcesses[ppn]).numPages; i ++){
			if ((VMKernel.clockFramesProcesses[ppn]).pageTable[i].valid == true && (VMKernel.clockFramesProcesses[ppn]).pageTable[i].ppn == ppn)
				return (VMKernel.clockFramesProcesses[ppn]).pageTable[i].dirty;
		}

		return false;
	}

	public static Boolean checkUsedByppn(int ppn){
		if (VMKernel.clockFramesProcesses[ppn] == null) return true;
		for (int i = 0; i < (VMKernel.clockFramesProcesses[ppn]).numPages; i ++){
			if ((VMKernel.clockFramesProcesses[ppn]).pageTable[i].valid == true && (VMKernel.clockFramesProcesses[ppn]).pageTable[i].ppn == ppn)
				return (VMKernel.clockFramesProcesses[ppn]).pageTable[i].used;
		}
		
		return false;
	}

	
	public static int getvpnByppn(int ppn){
		for (int i = 0; i < (VMKernel.clockFramesProcesses[ppn]).numPages; i ++){
			if ((VMKernel.clockFramesProcesses[ppn]).pageTable[i].valid == true && (VMKernel.clockFramesProcesses[ppn]).pageTable[i].ppn == ppn)
				return i;
		}
		
		return -1;
	}


	public static void setspnByppn(int ppn, int spn){
		if (VMKernel.clockFramesProcesses[ppn] == null) return;
		for (int i = 0; i < (VMKernel.clockFramesProcesses[ppn]).numPages; i ++){
			if ((VMKernel.clockFramesProcesses[ppn]).pageTable[i].valid == true && (VMKernel.clockFramesProcesses[ppn]).pageTable[i].ppn == ppn){
				(VMKernel.clockFramesProcesses[ppn]).pageTable[i].vpn = spn;
				return;
			}
		}
	
		return ;
	}


	public static void setUnusedByppn(int ppn){
		if (VMKernel.clockFramesProcesses[ppn] == null) return;
		for (int i = 0; i < (VMKernel.clockFramesProcesses[ppn]).numPages; i ++){
			if ((VMKernel.clockFramesProcesses[ppn]).pageTable[i].valid == true && (VMKernel.clockFramesProcesses[ppn]).pageTable[i].ppn == ppn){
				(VMKernel.clockFramesProcesses[ppn]).pageTable[i].used = false;
				return;
			}
		}
	
		return ;
	}

	public static void setInvalidByppn(int ppn){
		if (VMKernel.clockFramesProcesses[ppn] == null) return;
		for (int i = 0; i < (VMKernel.clockFramesProcesses[ppn]).numPages; i ++){
			if ((VMKernel.clockFramesProcesses[ppn]).pageTable[i].valid == true && (VMKernel.clockFramesProcesses[ppn]).pageTable[i].ppn == ppn){
				(VMKernel.clockFramesProcesses[ppn]).pageTable[i].valid = false;
				return;
			}
		}
		return ;
	}

    private static final int numPhysPages = Machine.processor().getNumPhysPages();

	//Used to track vpn from ppn.
	private int[] invertedPageTable = new int[numPhysPages];
    
	//The array of who is being pinned.
	private static boolean[] clockFramesPinned = new boolean[numPhysPages];

	private static int clockHandler = 0;

	private static int pinCount = 0;

	private static Condition waitForUnpinned = new Condition(VMKernel.pinLock);

	private static final int pageSize = Processor.pageSize;

	private static final char dbgProcess = 'a';

	private static final char dbgVM = 'v';
}