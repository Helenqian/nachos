package nachos.vm;

import java.util.*;
import nachos.machine.*;
import nachos.threads.*;
import nachos.userprog.*;
import nachos.vm.*;

/**
 * A kernel that can support multiple demand-paging user processes.
 */
public class VMKernel extends UserKernel {
	/**
	 * Allocate a new VM kernel.
	 */
	public VMKernel() {
		super();
	}

	/**
	 * Initialize this kernel.
	 */
	public void initialize(String[] args) {
		super.initialize(args);
		swapFile = ThreadedKernel.fileSystem.open("swapFile",true);
		pinLock = new Lock();
		memoryLock = new Lock();
		swapLock = new Lock();
		pageTableLock = new Lock();
		clockLock = new Lock();
		for (int i = 0; i < numPhysPages; i++){
			clockFramesProcesses[i] = null; 
		}
	}

	/**
	 * Test this kernel.
	 */
	public void selfTest() {
		super.selfTest();
	}

	/**
	 * Start running user programs.
	 */
	public void run() {
		super.run();
	}

	/**
	 * Terminate this kernel. Never returns.
	 */
	public void terminate() {
		super.terminate();
		swapFile.close();
		ThreadedKernel.fileSystem.remove("swapFile");
	}

	/**
	 * Swap out a frame to a swap file page.
	 *
	 * @param evictedFramePPN the ppn of the to-be-evicted frame.
	 * @return spn the spn of a swap file page.
	 */
	public static int swapOut(int evictedFramePPN) {
		//Allocate a swap file page.
		//To save space, here we use a little trick.
		//The swapFileList can track the spn that we have used so far
		//so that we won't leave some "holes" in our swap file.
		//When all used swap file pages are realeased, we now have to reallocate the page from spn = numSwapFile.  
		int spn;

		swapLock.acquire();
		if (swapFileList.isEmpty()) spn = numSwapFile;
		else 						spn = swapFileList.removeFirst();
		numSwapFile++;
		swapLock.release();

		//Store the content of the specified frame to a local buffer.
		byte[] memory = Machine.processor().getMemory();
		int paddr = evictedFramePPN * pageSize;
		byte[] buffer = new byte[pageSize];
		System.arraycopy(memory, paddr, buffer, 0, pageSize);

		//Write the buffer to a swap file page.
		int pos = spn * pageSize;
		swapFile.write(pos, buffer, 0, pageSize);

		return spn;
	}

	/**
	 * Swap in a swap file page to a frame.
	 *
	 * @param spn the spn of the to-be-swapped-in page.
	 * @param ppn the ppn of the frame we want to retrieve.
	 */		  
	public static void swapIn(int spn, int ppn) {
		swapLock.acquire();
		swapFileList.add(spn);
		numSwapFile--;
		swapLock.release();

		//Store the content of the specified swap file page to a local buffer.
		int pos = spn * pageSize;
		byte[] buffer = new byte[pageSize];
		swapFile.read(pos, buffer, 0, pageSize);

		//Write the buffer to a frame.
		byte[] memory = Machine.processor().getMemory();
		int paddr = ppn * pageSize;
		System.arraycopy(buffer, 0, memory, paddr, pageSize);
	}	

	public static boolean isAnyFreePage() {
		return !UserKernel.freePages.isEmpty();
	}

	public static int getFreePage() {
		memoryLock.acquire();
		int ppn = ((Integer)UserKernel.freePages.removeFirst()).intValue();
		memoryLock.release();

		return ppn;
	}

	public static void returnPage(int ppn) {
		VMKernel.memoryLock.acquire();
		UserKernel.freePages.add(ppn);
		VMKernel.memoryLock.release();
	}

	private static final int numPhysPages = Machine.processor().getNumPhysPages();

	private static final int pageSize = Machine.processor().pageSize;

	private static OpenFile swapFile;

	private static int numSwapFile = 0;

	public static Lock pinLock;

	public static Lock memoryLock;

	private static LinkedList<Integer> swapFileList = new LinkedList<Integer>();

	//The array of frames are being used by which process.
	public static VMProcess[] clockFramesProcesses = new VMProcess[numPhysPages];

	public static Lock swapLock;

	public static Lock pageTableLock;

	public static Lock clockLock;

	// dummy variables to make javac smarter
	private static VMProcess dummy1 = null;

	private static final char dbgVM = 'v';
}
