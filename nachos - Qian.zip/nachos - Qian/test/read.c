#include "syscall.h"
int main()
{
  int f1 = creat("hello.txt");
  }
